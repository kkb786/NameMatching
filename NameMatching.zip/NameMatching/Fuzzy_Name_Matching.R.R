library(ngramrr)
library(stringdist)


# Assuming text_dat is a data frame, with the NAMES column containing the 
# cleaned and processed data for this step (includes removing stop words, 
# fixing common spelling errors, and consolidating different ways of writing a word) 

# The following converts the properly spaced column containing text into a non-spaced column
# while replacing 0 length words with ---
 
text_dat$nonspaced <- unlist(lapply(X = text_dat$NAMES, FUN =
                                        function(x)
                                            if(length(unlist(str_split(x,"")))>1){
                                                gsub(" ", "", x)
                                            }else{
                                                "---"
                                            }
                                    )
                             )

##########################
# Ngrams
##########################


# Only using unique words from the list in order to not match 
# a name with itself multiple times

df <- text_dat[c('nonspaced', 'NAMES')
unique <- df[!duplicated(df), ]

nonspaced <-  unique$nonspaced
original <-  unique$NAMES

# Creating N grams for each name (Letter wise)

Uni <- lapply(X = nonspaced , FUN = 
                  function(x)
                      
                      if(length(unlist(str_split(x,""))) < 2){x}
              else{
                  ngramrr(x, char = T, ngmin = 1, ngmax = 1, rmEOL = T)
              }
              
)

Bi <- lapply(X = nonspaced, FUN = 
                 function(x)
                     
                     if(length(unlist(str_split(x,""))) < 2){x}
             else{
                 ngramrr(x, char = T, ngmin = 2, ngmax = 2, rmEOL = T)
             }
)

Tri <- lapply(X = nonspaced, FUN = 
                  function(x)
                      if(length(unlist(str_split(x,""))) < 2){x}
              else{
                  ngramrr( x, char = T, ngmin = 3, ngmax = 3, rmEOL = T)
              }                                    
)
Quad <- lapply(X = nonspaced, FUN = 
                   function(x)
                       if(length(unlist(str_split(x,""))) < 2){x}
               else{
                   ngramrr( x, char = T, ngmin = 4, ngmax = 4, rmEOL = T)
               }
)
Quint <- lapply(X = nonspaced, FUN = 
                    function(x)
                        if(length(unlist(str_split(x,""))) < 2){x}
                else{
                    ngramrr(x, char = T, ngmin = 5, ngmax = 5, rmEOL = T)
                }
)


#Storing the Ngram matches for a word

ngrams <- rep(list(list()), length(nonspaced))

#Storing the DL Matches for a word
dl <- rep(list(list()), length(nonspaced))


loop = 0
for(i in seq(1,length(nonspaced))){
    loop = loop +1
    print(loop)
    n=1
    m=1 
    b1 = 0
    b2 = 0
    
    for(j in seq(1,length(nonspaced))){
        # NGram overlap algorithm
        if(b1 == 0){
            uni = length(intersect(unlist(Uni[i]), unlist(Uni[j])))
            bi = length(intersect(unlist(Bi[i]), unlist(Bi[j])))
            tri = length(intersect(unlist(Tri[i]), unlist(Tri[j])))
            quad = length(intersect(unlist(Quad[i]), unlist(Quad[j])))
            quint = length(intersect(unlist(Quint[i]), unlist(Quint[j])))
            
            tot = uni+ 1.5*bi+2*tri+2.5*quad +3*quint
            
            s1 = length(unlist(Uni[i]))+ 
                1.5*length(unlist(Bi[i]))+
                2*length(unlist(Tri[i])) +
                2.5*length(unlist(Quad[i])) +
                3*length(unlist(Quint[i]))
            s2 = length(unlist(Uni[j]))+ 
                1.5*length(unlist(Bi[j]))+ 
                2*length(unlist(Tri[j])) + 
                2.5*length(unlist(Quad[j]) )+
                3*length(unlist(Quint[j]))
            s = min(s1,s2)
            
            ratio = tot/s
            if(unlist(str_split(nonspaced[i],""))[1] == unlist(str_split(nonspaced[j],""))[1]){
                ratio = ratio +0.08
            }
            
            # Not working with words with less than 3 characters
            if(length(unlist(str_split(text_dat_unique$nonspaced[i],"")))<3){
                ngrams[[i]] = c(nonspaced[i], "TOO FEW CHAR")
                b1 = 1
            }
            
            #Not working with words who have more than 30 matches
            if(n>30){
                ngrams[[i]] = c(nonspaced[i], "TOO MANY")
                b1 = 1
            }
            #Threshold of 0.8 used with experimentation. Should be adjusted depending on the data set being used
            if(ratio>0.80){
                if(s1/s2 < 10#& 
                   #length(unlist(str_split(original[j],""))) >2# & s1!=s2
                ){
                    #l = append(l,original[j])
                    
                    ngrams[[i]][n] = nonspaced[j]
                    n = n+1
                    
                }
            }
        }
        
        # DL Algorithm 
        l1 = length(unlist(Uni[j]))
        l2 = length(unlist(Uni[i]))
        l = min(l1,l2)
        if(l2 <4){
            b2 = 1
        }
        if(b2 ==0){
            
            k = stringdist(nonspaced[i],nonspaced[j])
            
            if(k <= max(round(l/5),2)){
                dl[[i]][m] = nonspaced[j]
                m = m+1
            }
            if(m >20){
                b2 =1
            }
        }
        if(b1 *b2 ==1){
            break
        }
    }
}
